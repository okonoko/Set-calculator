
public class Set {
	
	List <Identifier> IDs;
	
	Set(){
		IDs = new List<>(); // creates an empty list
	}
	public void addIdentifier(Identifier d) {
		if(!elementExist(d)) {
			IDs.insert(d); // add one element to set
		}
	}
	public boolean elementExist(Identifier d) {
		return IDs.find(d); // return true if element was found in the list, false if not
	}
	public Set Union(Set set) {
		
		Set UnionSet = new Set();
		IDs.goToFirst();
		set.IDs.goToFirst();
		
		for(int i = 0; i < set.IDs.size();i++) {
			UnionSet.addIdentifier(set.IDs.retrieve());	
			set.IDs.goToNext();
		}
        for(int i = 0; i < IDs.size(); i++) {
        	UnionSet.addIdentifier(IDs.retrieve());
        	IDs.goToNext();
        }
		return UnionSet;
	}
	public Set Intersection(Set set) {
		
		Set InterSet = new Set();
		IDs.goToFirst();
		set.IDs.goToFirst();
		
		for(int i = 0; i < set.IDs.size();i++) {
			if(elementExist(set.IDs.retrieve())) {
				InterSet.addIdentifier(set.IDs.retrieve());
			}
			set.IDs.goToNext();
		}
		
		return InterSet;
	}
	public Set Difference(Set set) {
		
		Set DiffSet = new Set();
		IDs.goToFirst();
		set.IDs.goToFirst();
		
		for(int i = 0; i < IDs.size();i++) {
			if(!set.elementExist(IDs.retrieve())) {
				DiffSet.addIdentifier(IDs.retrieve());
				
			}
			IDs.goToNext();
		}
		return DiffSet;
	}
	public Set SymetricDifference(Set set) {
		
		return Union(set).Difference(Intersection(set));
	}
	public void printSet() {
		IDs.goToFirst();
		System.out.print("{ ");
		for(int i = 0; i < IDs.size(); i++) {
			System.out.print(IDs.retrieve().value + " ");
			IDs.goToNext();
		}
		System.out.println("}");
		
	}

}
