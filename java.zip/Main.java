import java.util.Scanner;

public class Main {
	
	

    private void start() {
    	
    	Set set1 = new Set();
    	Set set2 = new Set();
        Identifier ID1 = new Identifier("345");
        Identifier ID2 = new Identifier("467");
        Identifier ID3 = new Identifier("709");
        Identifier ID4 = new Identifier("122");
        Identifier ID5 = new Identifier("345");
        Identifier ID6 = new Identifier("709");
        Identifier ID7 = new Identifier("807");
        set1.addIdentifier(ID1);
        set1.addIdentifier(ID2);
        set1.addIdentifier(ID3);
        set1.addIdentifier(ID4);
        set2.addIdentifier(ID5);
        set2.addIdentifier(ID6);
        set2.addIdentifier(ID7);
        
        System.out.println("Union: ");
        set1.Union(set2).printSet();
        System.out.println("Intersection: ");
        set1.Intersection(set2).printSet();
        System.out.println("Difference: ");
        set1.Difference(set2).printSet();
        System.out.println("SymDiff: ");
        set1.SymetricDifference(set2).printSet();
    }

    public static void main(String[] argv) {
        new Main().start();
    }
}
